# ONLINE-VOTING-SYSTEM-in-PHP-MYSQL

![onlinevotingsystem](https://cloud.githubusercontent.com/assets/16975766/23581990/7f504dda-0146-11e7-9320-43281a1bec01.png)


This system allows all registered users to vote for their favorite PROGRAMMING LANGUAGE.
In order to make a vote you have to register first and then login.

