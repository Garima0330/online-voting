<br>
<br>
<br>
<br>
<center><font color="red"><b><i>Declaration: </i></b></font><i> This application is published under GENERAL PUBLIC LICENSE on github.&nbsp;<a href="#" >Click Here </a> to get the full source code.</i></center>
</body>
</html>