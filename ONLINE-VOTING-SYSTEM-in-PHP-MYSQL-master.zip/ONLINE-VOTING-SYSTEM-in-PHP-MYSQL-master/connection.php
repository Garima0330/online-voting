<?php 
$con = mysqli_connect("localhost","root","server24","polltest") or die ("error" . mysqli_error($con));
?>
